const collection = 'todo'

const saveEmployeeTodoList = (data, db, callback) => {
    db.collection(collection).insertOne(data, (error, result) => {
        if (error) callback('error', undefined)
        callback(undefined, result)
    })
}

const fetchEmployeeTodoList = (db, callback) => {
    db.collection(collection).find({}).toArray((error, result) => {
        if (error) callback(error, undefined)
        callback(undefined, result)
    })
}

module.exports = { saveEmployeeTodoList, fetchEmployeeTodoList }